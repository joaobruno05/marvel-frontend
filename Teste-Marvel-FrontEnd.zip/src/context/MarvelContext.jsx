import { createContext } from 'react';

const MarvelContext = createContext();

export default MarvelContext;
